#!/bin/bash

# Install nvm for this shell
source ~/.nvm/nvm.sh

# Use node.js at 4.2.x
nvm install 4.4
